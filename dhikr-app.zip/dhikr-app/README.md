# Dhikr Counter — мобильное приложение

Готовый комплект файлов для превращения `index.html` в APK (Android) и IPA (iOS)
через **Cordova**. Дизайн и логика оригинального HTML не менялись — добавлены
только `manifest.json`, `sw.js` и мета‑теги для корректной работы как
приложение (PWA / WebView‑обёртка).

## Структура проекта

```
dhikr-app/
├── config.xml          # конфигурация Cordova (id, иконки, платформы, плагины)
├── package.json        # npm-скрипты для сборки
├── README.md
└── www/                 # содержимое веб-приложения (то, что попадёт в APK/IPA)
    ├── index.html        # ваш оригинальный файл + PWA-теги + регистрация SW
    ├── manifest.json     # метаданные PWA (имя, цвета, ориентация, иконки)
    ├── sw.js             # service worker для офлайн-работы
    └── icons/            # иконки 48–1024px для Android и iOS
```

## 1. Установка окружения

Понадобится **Node.js** (18+) и npm.

```bash
npm install -g cordova
cd dhikr-app
npm install
```

## 2. Добавление платформ

```bash
# Android
npm run add:android

# iOS (только на macOS с установленным Xcode)
npm run add:ios
```

## 3. Сборка

### Android → APK

```bash
npm run build:android
```

Debug‑APK появится в:
`platforms/android/app/build/outputs/apk/debug/app-debug.apk`

Для **релизного** APK/AAB (для Google Play) нужен ключ подписи:

```bash
keytool -genkey -v -keystore release-key.keystore -alias dhikr -keyalg RSA -keysize 2048 -validity 10000
npm run build:android:release
```

Cordova спросит путь к keystore и пароль (или настройте
`build.json`, см. [документацию Cordova](https://cordova.apache.org/docs/en/latest/guide/platforms/android/#signing-an-app)).
Итоговый файл нужно подписать (`jarsigner`/`apksigner`) и выровнять
(`zipalign`) перед загрузкой в Google Play, либо сразу собрать `.aab`:

```bash
cordova build android --release -- --packageType=bundle
```

### iOS → IPA (только на macOS)

```bash
npm run build:ios
```

Затем откройте проект в Xcode:

```bash
open platforms/ios/DhikrCounter.xcworkspace
```

В Xcode:
1. Выберите свою команду разработчика (Signing & Capabilities).
2. Product → Archive.
3. В Organizer нажмите **Distribute App** → App Store Connect (или Ad Hoc для
   тестирования) — получите `.ipa`.

Для загрузки в App Store также нужна активная **Apple Developer Program**
подписка ($99/год) и настроенные Bundle ID / профили в App Store Connect.

## 4. Проверка перед сборкой

```bash
npm run serve
```
Откройте `http://localhost:8000` — это то же самое, что увидит WebView.

## 5. Публикация

- **Google Play**: загрузите подписанный `.aab`/`.apk` в
  [Google Play Console](https://play.google.com/console) (нужен аккаунт
  разработчика, разовый платёж $25).
- **App Store**: загрузите `.ipa` через Xcode Organizer или
  `xcrun altool` в [App Store Connect](https://appstoreconnect.apple.com).

## Что уже настроено

| Файл | Назначение |
|---|---|
| `manifest.json` | Имя `Dhikr Counter`, цвет темы `#C9A84C` (золотой, как акцент приложения), фон `#F7F5F0`, портретная ориентация, иконки 48–512px |
| `sw.js` | Кэширует `index.html`, `manifest.json` и иконки — приложение открывается офлайн после первого запуска |
| `config.xml` | `id`: `com.dhikrcounter.app`, портретная ориентация, цвет статус-бара и splash-фон под дизайн приложения, минимальные версии Android/iOS, плагин `cordova-plugin-vibration` |
| `icons/` | PNG 48, 57, 60, 72, 76, 96, 120, 144, 152, 180, 192, 512, 1024 px — покрывают все размеры для Android (`mipmap`) и iOS (`AppIcon`) |

### Вибрация при нажатии

В `index.html` добавлена функция `vibrate(ms)`, которая пробует по очереди:
1. **Capacitor Haptics** (`Capacitor.Plugins.Haptics.impact()`) — если проект собран через Capacitor;
2. **`navigator.vibrate()`** — работает нативно в Android WebView и добавляется на iOS через `cordova-plugin-vibration` (уже прописан в `config.xml`/`package.json`);
3. Если ничего не доступно (например, десктоп-браузер) — тихо ничего не делает.

Для Capacitor-сборки дополнительно поставьте:
```bash
npm install @capacitor/haptics
npx cap sync
```

## Важно

- **App ID** в `config.xml` (`com.dhikrcounter.app`) и **имя пакета** в
  `package.json` — замените на свои, если публикуете под другим брендом
  (изменить обратный домен нужно один раз, до первой публикации — потом
  сменить его в сторах сложно).
- Приложение использует шрифт Google Fonts (`Poppins`) по сети — при полном
  офлайне до первой загрузки страница используeт системный шрифт-фолбэк
  (`system-ui`), это уже заложено в оригинальный CSS.
- Если хотите использовать **Capacitor** вместо Cordova (более современная
  альтернатива с тем же `www/`):
  ```bash
  npm install @capacitor/core @capacitor/cli
  npx cap init "Dhikr Counter" "com.dhikrcounter.app" --web-dir=www
  npx cap add android
  npx cap add ios
  npx cap sync
  npx cap open android   # или ios
  ```
  `manifest.json`, `sw.js` и иконки в `www/` подойдут без изменений.
